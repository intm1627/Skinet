# ntskinet
My version of skinet
Using net core and angular on VS Code Feb 2021
